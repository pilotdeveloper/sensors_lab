[
		{
			question: "How did we first meet?",
			answer: ["Robotics Competition", "Facebook", "Gay Bar", "World of Warcraft"],
			correctAnswer: "b",
			points: 10
		},
		{
			question: "Where was our first kiss?",
			answer: ["Pickup Truck", "High School Bleachers", "Reedy River Park", "World of Warcraft"],
			correctAnswer: "a",
			points: 10
		},
		{
			question: "Where was our second first date?",
			answer: ["Grocery Store", "Rollerskating Rink", "Clemson Dining Hall", "World of Warcraft"],
			correctAnswer: "a",
			points: 10
		},
		{
			question: "What's the farthest we've been apart?",
			answer: ["989 miles", "2842 miles", "3800 miles", "World of Warcraft"],
			correctAnswer: "c",
			points: 10
		},
		{
			question: "What's our favorite game to play together?",
			answer: ["Starcraft", "Hearthstone", "Animal Crossing: New Leaf", "Rec Room"],
			correctAnswer: "d",
			points: 10
		},
		{
			question: "What does Alex always leave all over the apartment?",
			answer: ["Tissues", "A trail of cereal", "Half-empty La Croix cans", "Dirty socks"],
			correctAnswer: "c",
			points: 10
		},
		{
			question: "What does Jalysa always leave in her jeans before they're washed?",
			answer: ["Pencils", "Tissues", "Receipts", "Nothing, because she is perfect."],
			correctAnswer: "b",
			points: 10
		},
		{
			question: "How many blankets are on our bed at all times?",
			answer: ["1", "2", "3", "None, because the apartment is kept at reasonable temperature."],
			correctAnswer: "c",
			points: 10
		},
		{
			question: "Where did we go ghosthunting together?",
			answer: ["Graveyard", "General Store", "Abandoned Church", "Plantation House"],
			correctAnswer: "a",
			points: 10
		},
		{
			question: "As of today, how long have we been together?",
			answer: ["2 weeks", "2 hours", "6 years", "7 years"],
			correctAnswer: "d",
			points: 10
		},
		{
			question: "Where was our second first kiss?",
			answer: ["The lake", "Flat Rock", "Pretty Place", "We haven't kissed since 2008"],
			correctAnswer: "a",
			points: 10
		},
		{
			question: "What is our song?",
			answer: ["Forever by Chris Brown", "Inspiration by Chicago", "All-Star by Smash Mouth", "Faithfully by Journey"],
			correctAnswer: "d",
			points: 10
		},
		{
			question: "Where did Alex propose to Jalysa?",
			answer: ["Kishi Bashi NYE concert", "Creed NYE concert", "Universal Orlando's Harry Potter World", "Pickens County BP Gas Station"],
			correctAnswer: "a",
			points: 10
		},
		{
			question: "What did Alex bet Jalysa couldn't do while in Clemson?",
			answer: ["Pass all Comp Sci classes with an A", "Cuddle with him for 5 minutes", "Eat a teaspoon of garlic", "Get into art school and achieve her dreams"],
			correctAnswer: "b",
			points: 10
		},
		{
			question: "What is Jalysa's signature dish?",
			answer: ["Eggs and rice", "Cereal", "Eggo waffles", "Banana muffins"],
			correctAnswer: "d",
			points: 10
		},
		{
			question: "What is Alex's signature dish?",
			answer: ["Revenge served cold", "Beef stew", "Pulled pork", "Mac 'n Cheesey"],
			correctAnswer: "c",
			points: 10
		},
		{
			question: "Which wi-fi network is not ours?",
			answer: ["Hyrule", "Lowrule", "FuckComcast", "FuckComcastHard"],
			correctAnswer: "b",
			points: 10
		},
		{
			question: "How many mild packets does Alex take every time we go to Taco Bell?",
			answer: ["1 handful", "2 handfuls", "3 per taco", "None.  He avoids being wastful and cares deeply for the environment."],
			correctAnswer: "c",
			points: 10
		},
		{
			question: "What does Jalysa always steal from Alex's Taco Bell order?",
			answer: ["Quesorito", "Crunchwrap Supreme", "Empanada", "2 handfuls of mild packets"],
			correctAnswer: "a",
			points: 10
		},
		{
			question: "What are our terms of endearment for each other?",
			answer: ["Honeybunny and Fart Nugget", "Kitty and Boo", "Babe and Babe", "Sugah Bayuh and Punkin"],
			correctAnswer: "b",
			points: 10
		},
		{
			question: "What are the names of our Build-A-Bears?",
			answer: ["Alexica and Jalysica", "Michel and Jesse", "Mikey and JC", "Kittycakes and Boocakes"],
			correctAnswer: "c",
			points: 10
		},
		{
			question: "Why are we together?",
			answer: ["It takes 2 to summon LORD JARAXXUS, EREDAR LORD OF THE BURNING LEGION!!", "We are studying each other to understand the human equation", "Our collective height is 11 feet 7 inches", "We kinda like each other"],
			correctAnswer: "d",
			points: 10
		}	
]